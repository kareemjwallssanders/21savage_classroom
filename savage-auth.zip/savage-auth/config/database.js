// config/database.js
module.exports = {'url' :'mongodb+srv://demo:demo@21savageauth-gvo5j.mongodb.net/test?retryWrites=true',
'dbName':'21savageauth'
};


